Thanks for the call today. As agreed, here's the code test. Please reply by 4pm PST. Thanks.

1. Implement atoi: convert string to integer. Here's a description of the function if you are not familiar with it http://www.cplusplus.com/reference/cstdlib/atoi/

a) Write the code in Java, C#, or C/C++, only need the function itself.
b) How to test your code? Give a few critical test cases.

2. Reverse words in a string

Write a function, which takes a string of multiple words and returns a string on which words are reversed in order. For example, if input is "PHP is the best programming language", the output should be "language programming best the is PHP".