# atoi
## Description
Implement atoi: convert string to integer. Here's a description of the function if you are not familiar with it http://www.cplusplus.com/reference/cstdlib/atoi/

## Getting started

```
$ gcc -Wall -Werror -Wextra main.c atoi.c # to compile
$ ./a.out "-123" # to execute

```