AeroFS Coding Challenge

Getting Started

* Compile the java program and source files in testing folder using:

```
$ javac -classpath . *.java #compiled by
$ java -ea challenge #run by with assertions
$ java challenge #run by without assertions
```

Production
* function

Production
* use production folder to publish your code to live.
Development
* use development folder for any further development or staging production codes.

Testing
* Used assertions and printing out the values for any misbehaviors that the function might have.


For Matthew Pillar,
Please use Testing folder to test with test cases.