var _ = require('underscore');


/*
  @param data: hash
  @param group_by: integer, 0: year, 1: month, 2: week,3: 90 days, 4: 120 days
  @return hash of grouped data
*/
function groupData(data, group_by) {

  let sorted = _.sortBy(data, function(obj) { return obj.timestamp; });

  if (group_by === 0) {
    return _.groupBy(sorted, function(item) {
      return item.timestamp.substring(0,4);
    });
  } else if (group_by === 1) {
    return _.groupBy(sorted, function(item) {
      return item.timestamp.substring(0,7);
    });
  } else {
    return groupByDays(sorted,group_by);
  }
}

/*
  @param data: hash
  @param group_by: integer, 2: 90 days, 3: 120 days
  @return hash of grouped data
*/
function groupByDays(data, group_by) {
  //Initializations
  let groups = {};

  // edge cases
  if (group_by < 2 || group_by > 4) {
    throw new Error("GroupByDays function does not accept invalid group_by input. Please, choose a valid input.");
  }
  if (group_by === 2) {
    groupByDaysHelper(data,groups,7);
  } else if (group_by === 3) {
    groupByDaysHelper(data,groups,90);
  }
  else {
    groupByDaysHelper(data,groups,120);
  }
  return groups;
}

function groupByDaysHelper(sorted_data,groups,interval) {
  let current = new Date(sorted_data[0].timestamp);
  let index = 0;

  // set the initial current and group
  groups[sorted_data[0].timestamp] = [sorted_data[0]];

  // Goal is to group elements by time interval given by the function.
  // Sorted data will have objects in incresasing timestamp order.
  for (let i = 1; i < sorted_data.length; ++i) {
    let temp = new Date(sorted_data[i].timestamp);
    let timeDiff = Math.abs(current - temp);
    let diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

    // Check if difference in days are within interval days
    if (diffDays <= interval) {
      groups[sorted_data[index].timestamp].push(sorted_data[i]);
      continue;
    }

    if (!groups[sorted_data[i].timestamp]) {
      groups[sorted_data[i].timestamp] = [sorted_data[i]];
      current = temp;
      index = i;
    }
  }
}

/*
  function worstExerciseDays
  @param data: hash
  @param group_by: integer, 0: year, 1: month, 2: 90 days
  @return new_data: list, top 3 exercise objects
*/
function worstExerciseDays(data, group_by) {
  let bot3 = data.sort(function(a,b) {
    return a['duration'] > b['duration'];
  });
  return groupData(bot3.slice(0,3),group_by);
};

/*
  function bestExerciseDays
  @param data: hash
  @param group_by: integer, 0: year, 1: month, 2: 90 days
  @return new_data: list, bottom 3 exercise objects
*/
function bestExerciseDays(data, group_by) {
  let top3 = data.sort(function(a,b) {
    return a['duration'] < b['duration'];
  });
  return groupData(top3.slice(0,3),group_by);
}

/*
  function worstExerciseBreak
  @param data: hash
  @param group_by: integer, 0: year, 1: month, 2: 90 days
  @return new_data: object, the worst exercise break
*/
function worstExerciseBreak(data, group_by) {
  let sorted = _.sortBy(data, function(obj) { return obj.timestamp; });
  let time = 0;

  // iterate through the sorted data and check the time interval between
  // every other timestamp.
  for (let i = 0; i < sorted.length-1; ++i) {
    let current = new Date(sorted[i].timestamp);
    let temp = new Date(sorted[i+1].timestamp);
    let timeDiff = temp - current;
    let diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

    if (diffDays > time) {
      time = diffDays;
    }
  }
  return time;
}
/*
  function bestExerciseStreak
  @param data: hash
  @param group_by: integer, 0: year, 1: month, 2: 90 days
  @return new_data: list, best exercise 3 streak
*/
function bestExerciseStreak(data, group_by) {
  let sorted = _.sortBy(data, function(obj) { return obj.timestamp; });
  let groups = {};
  let candidates = [];
  groupByDaysHelper(sorted,groups,3);
  // iterate through groups and pick ones that have >=3 objects
  for (let key in groups) {
    if (groups[key].length >= 3) {
      candidates.push(groups[key]);
    }
  }
  if (candidates.length > 0) {
    // get top 3 objects for each candidates
    for (let i = 0; i < candidates.length; ++i) {
      candidates[i].sort((a,b) => a['duration'] < b['duration']);
      candidates[i] = candidates[i].slice(0,3);
    }
    // sort candidates by sum of three durations
    candidates = _.sortBy(candidates, function(list) { return list.reduce((x,y) => x['duration']+y['duration'],0)});
  } else {
    return [];
  }
  return candidates[0];
}


/*
  function exerciseIsBestMedicine
  @param readings: hash
  @param group_by: integer, 0: year, 1: month, 2: 90 days
  @return new_data: hash, a hash value which contains all the reports
*/
function exerciseIsBestMedicine(readings,group_by){
  //convert hash to data
  let data = readings['readings'];
  let new_data = {};
  //Best exercise days TOP 3
  new_data['bestExerciseDays'] = bestExerciseDays(data, group_by);
  //Worst exercise days BOT 3
  new_data['worstExerciseDays'] = worstExerciseDays(data, group_by);
  //Best exercise streak is 3 consecutive days of exercise
  new_data['best3Consecutive'] = bestExerciseStreak(data, group_by);

  new_data['worstExerciseBreak'] = worstExerciseBreak(data, group_by);

  new_data['groupedData'] = groupData(data, group_by);
  return new_data;
};


var readings = {"readings": [ {"duration": 40, 'timestamp': '2016-08-29T11:15:34'}, { "duration": 31, 'timestamp': '2015-04-15T11:15:34'}, {"duration": 12, 'timestamp': '2015-07-29T11:15:34'},{ "duration": 23, 'timestamp': '2015-05-25T11:15:34'}, {"duration":50,'timestamp':'2015-04-16T11:15:34'},{"duration":10,'timestamp':'2016-09-16T08:25:34'}, {"duration": 40, 'timestamp': '2015-04-17T11:15:34'}]};

var readings2 = {"readings": [ {"duration": 50, 'timestamp': '2016-08-29T11:15:34'},{"duration": 50, 'timestamp': '2016-08-30T11:15:34'},{"duration": 40, 'timestamp': '2016-08-29T11:15:34'}, { "duration": 55, 'timestamp': '2015-04-15T11:15:34'}, {"duration": 55, 'timestamp': '2015-04-14T11:15:34'},{ "duration": 55, 'timestamp': '2015-04-13T11:15:34'},{ "duration": 23, 'timestamp': '2015-04-16T11:15:34'}, {"duration":50,'timestamp':'2015-04-16T11:15:34'},{"duration":10,'timestamp':'2016-09-16T08:25:34'}, {"duration": 40, 'timestamp': '2016-09-17T11:15:34'},{"duration":10,'timestamp':'2016-09-16T08:25:34'}, {"duration": 40, 'timestamp': '2016-09-17T11:15:34'}]};


var data = readings['readings'];
var data2 = readings2['readings'];
// data test: check if data is converting readings correctly
console.log('-----------Welcome to Testing-----------');
console.log('my test JSON object is:');
console.log(readings);
console.log('-----------Main Function Testing with console logs-----------');
console.log('-----------Feel free to modify group_by parameter (2nd param)-----------');
var testMainFunction = exerciseIsBestMedicine(readings,0);
console.log(testMainFunction);

console.log('-----------Functional Testing with console logs-----------');
console.log('---------------------Let\'s get started!---------------------------------');
// groupByDays: this should group objects by dates
console.log('groupByDays');
var testGroupByDays = groupByDays(data,2);
console.log(testGroupByDays);
console.log('-----------------------------------------------------');

console.log('groupData group_by year');
var testGroupData = groupData(data,0);
console.log(testGroupData);
console.log('-----------------------------------------------------');

console.log('groupData group_by month');
var testGroupData = groupData(data,1);
console.log(testGroupData);
console.log('-----------------------------------------------------');

console.log('groupData group_by week');
var testGroupData = groupData(data,2);
console.log(testGroupData);
console.log('-----------------------------------------------------');

console.log('groupData group_by 90 days');
var testGroupData = groupData(data,3);
console.log(testGroupData);
console.log('-----------------------------------------------------');

console.log('groupData group_by 120 days');
var testGroupData = groupData(data,4);
console.log(testGroupData);
console.log('-----------------------------------------------------');

// BestExerciseDays test: check if there are three best exercise days
console.log('bestExerciseDays');
var testBestExerciseDays = bestExerciseDays(data, 0);
console.log(testBestExerciseDays);
console.log('-----------------------------------------------------');

// worstExerciseDays test: check if there are three best exercise days
console.log('worstExerciseDays');
var testWorstExerciseDays = worstExerciseDays(data, 0);
console.log(testWorstExerciseDays);
console.log('-----------------------------------------------------');

console.log('worstExerciseBreak');
var testWorstExerciseBreak = worstExerciseBreak(data, 0);
console.log(testWorstExerciseBreak);
console.log('-----------------------------------------------------');

// BestExerciseStreak test: check if there is a streak
console.log('bestExerciseStreak (using data2)');
var testBestExerciseStreak = bestExerciseStreak(data2,0);
console.log(testBestExerciseStreak);
console.log('-----------------------------------------------------');
