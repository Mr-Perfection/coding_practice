# Coding Challenge Submission

## Getting started
* I used CoderPad(https://coderpad.io/JGR3H9Y9, highly recommended) and JSFiddle(https://jsfiddle.net/sungsool/ctwvubnk/) to do this coding challenge.
* This is not a standalone program and needs to be tested with either web browser,JSFiddle or CoderPad (Highly recommended).

## Implementation
I wrote the entire code in about 4-5 hours (3 hours yesterday and 2 hours today) without including the time of writing this documentation.
First, I looked through the guideline and made reasonable assumptions (I will tell you which assumptions I made). Secondly, I started writing codes by each function that needs to perform based on the requirements.
```js
function groupData(data, group_by){...}; // this will group data by given group_by input (integer, 0: year, 1: month, 2: week,3: 90 days, 4: 120 days).
function groupByDays(data, group_by){...}; // group by week, 90 days... need to perform using time interval between timestamps.
function groupByDaysHelper(sorted_data,groups,interval) {...}; // refactored the codes that are in groupByDays to reduce redundancies.
function worstExerciseDays(data, group_by) {...}; //I made a reasonable assumption that I would select the worst 3 exercise dates.
function bestExerciseDays(data, group_by) {...}; //I made a reasonable assumption that I would select the best 3 exercise dates.
function worstExerciseBreak(data, group_by) {...}; //I made a reasonable assumption that I would find a longest break between respective timestamps. Calculated in days.
function bestExerciseStreak(data, group_by) {...}; //I made a reasonable assumption that I would find the longest sum of durations of 3 consecutive exercises.


function exerciseIsBestMedicine(readings,group_by){...}; //this is the main function which will contain all the functions above.
```

## Conclusion
If this was meant for the application, I would create a data visualization and make a graph/chart for patients. Also, a lot of this client-side codes can be done in the backend (preferably relational database like PostgreSQL) such as sorting by timestamps. This could be much more performance-driven and reduce huge computational overhead. Since data is already given to me, I have decided to write a Javascript to demonstrate my knowledge and my thought process. Overall, it was fun doing this coding challenge and have got to learn more in ES6.
Thank you for your time, and I hope to hear back from you soon.
